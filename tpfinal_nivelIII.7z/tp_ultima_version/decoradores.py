def decoradorestp(func): 
    def envoltura(*args):
        if "funcion_guardar" in func.__name__:
            print("Se relizo el guardado de un nuevo Socio")
            for i in range(1, len(args)):
                if "get" in dir(args[i]):
                    print(args[i].get())
        elif "funcion_eliminar" in func.__name__:
            print("Se borro un Socio")
        func(*args)

    return envoltura