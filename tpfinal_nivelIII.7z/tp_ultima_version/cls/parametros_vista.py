from tkinter import Entry
from tkinter import Menu
from tkinter import Label
from tkinter import CENTER
from cls.estilo import b_fg,b2_size,b1_bg,b_bg,b_font,b_size,b_style,b1_size

class Pantalla():
    def __init__(self, master):
        self.master=master
    
    def titulos(self,):
        self.lbl_titulo = Label(self.master, text="ADMINISTRACION DE SOCIOS")
        self.lbl_titulo.config(
            font=(b_font, b_size, b_style), fg=b_fg, bg=b_bg, anchor=CENTER
        )
        self.lbl_titulo.grid(row=0, column=1)

    
    def nombre_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        nombre=Label( self.master,
            text=self.text,
            font=(b_font,b1_size,b_style),
            bg=b_bg,
            fg=b_fg,)
        nombre.grid(row=self.row,column=self.column,sticky=self.sticky)
    
    def apellido_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        apellido=Label(self.master,
            text=self.text,
            font=(b_font,b1_size,b_style),
            bg=b_bg,
            fg=b_fg,)
        apellido.grid(row=self.row,column=self.column,sticky=self.sticky)
    
    def dni_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        dni=Label(self.master, text=self.text, font=(b_font,b1_size,b_style), bg=b_bg, fg=b_fg)
        dni.grid(row=self.row,column=self.column,sticky=self.sticky)

    def sexo_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        sexo=Label( self.master, text=self.text, font=(b_font,b1_size,b_style), bg=b_bg, fg=b_fg)
        sexo.grid(row=self.row,column=self.column,sticky=self.sticky)

    def telefono_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        telefono=Label(self.master,
            text=self.text,
            font=(b_font,b1_size,b_style),
            bg=b_bg,
            fg=b_fg,)
        telefono.grid(row=self.row,column=self.column,sticky=self.sticky)

    def email_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        email=Label(self.master,
            text=self.text,
            font=(b_font,b1_size,b_style),
            bg=b_bg,
            fg=b_fg,)
        email.grid(row=self.row,column=self.column,sticky=self.sticky)

    def direccion_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        direccion=Label(self.master,
            text=self.text,
            font=(b_font,b1_size,b_style),
            bg=b_bg,
            fg=b_fg,)
        direccion.grid(row=self.row,column=self.column,sticky=self.sticky)
    
    def estado_de_cuenta_label(self,text,row,column,sticky):
        self.text=text
        self.row=row
        self.column=column
        self.sticky=sticky
        estado_de_cuenta=Label(self.master,
            text=self.text,
            font=(b_font,b1_size,b_style),
            bg=b_bg,
            fg=b_fg,)
        estado_de_cuenta.grid(row=self.row,column=self.column,sticky=self.sticky)

    def nombre_entry(self,textvariable,width,row,column):
        self.textvariable=textvariable
        self.width=width
        self.row=row
        self.column=column
        nombre=Entry(self.master, textvariable=self.textvariable, width=self.width)
        nombre.grid(row=self.row,column=self.column)
    
    def apellido_entry(self,textvariable,width,row,column):
        self.textvariable=textvariable
        self.width=width
        self.row=row
        self.column=column
        apellido=Entry(self.master, textvariable=self.textvariable, width=self.width)
        apellido.grid(row=self.row,column=self.column)
    
    def dni_entry(self,textvariable,width,row,column):
        self.textvariable=textvariable
        self.width=width
        self.row=row
        self.column=column
        dni=Entry(self.master,
            textvariable=self.textvariable,
            width=self.width,)
        dni.grid(row=self.row,column=self.column)
    
    def telefono_entry(self,textvariable,width,row,column):
        self.textvariable=textvariable
        self.width=width
        self.row=row
        self.column=column
        telefono=Entry(self.master,
            textvariable=self.textvariable,
            width=self.width,)
        telefono.grid(row=self.row,column=self.column)
    
    def email_entry(self,textvariable,width,row,column):
        self.textvariable=textvariable
        self.width=width
        self.row=row
        self.column=column
        email=Entry(self.master,
            textvariable=self.textvariable,
            width=self.width,)
        email.grid(row=self.row,column=self.column)
    
    def direccion_entry(self,textvariable,width,row,column):
        self.textvariable=textvariable
        self.width=width
        self.row=row
        self.column=column
        direccion=Entry(self.master, textvariable=self.textvariable, width=self.width)
        direccion.grid(row=self.row,column=self.column)

    def estado_de_cuenta_entry(self,textvariable,width,row,column):
        self.textvariable=textvariable
        self.width=width
        self.row=row
        self.column=column
        estado_de_cuenta=Entry(self.master, textvariable=self.textvariable, width=self.width)
        estado_de_cuenta.grid(row=self.row,column=self.column)

    
    
    

