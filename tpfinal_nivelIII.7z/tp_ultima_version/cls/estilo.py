b_font="arial"
b_size=16
b_style="bold"
b_fg="green"
b_bg="white"
b1_size=12
b1_bg="red"
b2_size=8