from servidorestp import HOST
from servidorestp import PORT
import socket


def grabado(msg):
    soc = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    soc.sendto(msg.encode("UTF-8"), (HOST, PORT))
