from tkinter import *
from tkinter.ttk import Entry
from tkinter import messagebox
import re
import peewee
from peewee import CharField, SqliteDatabase, Model, FixedCharField, FloatField, DateField
import os
import datetime
import socket
from decoradores import decoradorestp
from observador import Subject
from clientetp import grabado


mi_id = 0
sex = [" ", "Femenino", "Masculino"]

db = SqliteDatabase("club_python.db")


class BaseModel(Model):
    class Meta:
        database = db


class Socios(BaseModel):
    nombre = CharField()
    apellido = CharField()
    dni = CharField()
    sexo = CharField()
    telefono = CharField()
    email = CharField()
    direccion = CharField()
    estado_de_cuenta = FloatField()


db.connect()
db.create_tables([Socios])




class RegistrodeError(Exception):

    BASE_DIR = os.path.dirname((os.path.abspath(__file__)))
    ruta = os.path.join(BASE_DIR, "log_abmc_socios.txt")
    
    def __init__(self, linea, archivo, fecha):
        self.linea = linea
        self.archivo = archivo
        self.fecha = fecha

    def registrar_error(self):
        log = open(self.ruta, "a")
        print(
            self.fecha,
            "- ERROR - ",
            self.archivo,
            self.linea,
            file=log,
        )

    def registrar_guardar(self):
        log = open(self.ruta, "a")
        print(
            "Se ha registrado un guardado de socio:",
            self.archivo,
            self.linea,
            self.fecha,
            file=log,
        )
    
    def registrar_eliminar(self):
        log = open(self.ruta, "a")
        print(
            "Se ha registrado una eliminacion de socio:",
            self.archivo,
            self.linea,
            self.fecha,
            file=log,
        )

    def registrar_modificar(self):
        log = open(self.ruta, "a")
        print(
            "Se ha registrado una modificacion de socio:",
            self.archivo,
            self.linea,
            self.fecha,
            file=log,
        )


def error_alguardar():
    raise RegistrodeError("guardar", "Registro de error", datetime.datetime.now())


def registrode_guardar():
    raise RegistrodeError("guardar", "registro de socio", datetime.datetime.now())

def error_aleliminar():
    raise RegistrodeError("quitar", "Registro de error", datetime.datetime.now())

def registrode_eliminar():
    raise RegistrodeError("quitar", "eliminacion de socio", datetime.datetime.now())

def error_almodificar():
    raise RegistrodeError("modificar", "Registro de error", datetime.datetime.now())

def registrode_modificar():
    raise RegistrodeError("modificar", "modificacion de socio", datetime.datetime.now())


class Abmc(Subject):
    def __init__(
        self,
    ):
        pass 
    
    @decoradorestp
    # btn guardar
    def funcion_guardar(
        self,
        nombre,
        apellido,
        dni,
        sexo,
        telefono,
        email,
        direccion,
        estado_de_cuenta,
        tree,
    ):
        ctrl = 0
        if not nombre:
            messagebox.showwarning("ADVERTENCIA", "No hay datos cargados")
        else:
            # controla si el di esta cagado
            ctrl_dni = dni.get()
            socio = Socios()
            pp = Socios.select(Socios.dni).where(Socios.dni == dni.get())

            for ctrl_dni in pp:
                messagebox.showwarning(
                    "ADVERTENCIA",
                    f"El DNI = {dni.get()}, ya fue ingresado solo admite actualizacion",
                )
                ctrl = 1
                break

            if ctrl == 1:
                pass
            else:
                ctrl = 0
                patron = r"\"?([-a-zA-Z0-9.`?{}]+@\w+\.\w+)\"?"
                socio = Socios()
                socio.nombre = nombre.get()
                socio.apellido = apellido.get()
                socio.dni = dni.get()
                socio.sexo = sexo.get()
                socio.telefono = telefono.get()
                socio.email = email.get()
                socio.direccion = direccion.get()
                socio.estado_de_cuenta = estado_de_cuenta.get()
                if re.match(patron, socio.email):
                    try:
                        socio.save()
                        messagebox.showinfo("Guardar", "Guardado correctamente")
                        registrode_guardar()
                    except RegistrodeError as log:
                        log.registrar_guardar()                    
                else:
                    print("error en campo del email")
                    messagebox.showinfo("Guardar", "Error en tipeo del email")
                    try:
                        socio.save()
                        error_alguardar()
                    except RegistrodeError as log:
                        log.registrar_error()
                self.notificar("agregar", socio.__dict__)
                grabado(f"agregar - {str(socio.__dict__)}")
                self.funcion_actualizartree(tree)
                nombre.set("")
                apellido.set("")
                dni.set("")
                sexo.current(0)
                telefono.set("")
                email.set("")
                direccion.set("")
                estado_de_cuenta.set("")

    # btn eliminar
    def funcion_eliminar(self, tree):
        # eliminar dato de base
        # global mi_id
        try:
            registrode_eliminar()
        except RegistrodeError as log:
            log.registrar_eliminar()
        
        item_seleccionado = tree.focus()
        item_id = tree.item(item_seleccionado)
        print(item_id)
        eliminar = Socios.get(Socios.id == item_id["text"])
        eliminar.delete_instance()
        self.notificar("quitar", eliminar.__dict__)
        grabado(f"quitar - {str(eliminar.__dict__)}")
        
        self.funcion_actualizartree(tree)
        
        
    # btn consultar
    def funcion_consultar(
        self,
        var_id,
        var_nombre,
        var_apellido,
        var_dni,
        cmbox_sexo,
        var_telefono,
        var_email,
        var_direccion,
        var_estado_de_cuenta,
        tree,
    ):
        # cargar los entry con el dato selecionada de la tabla
        global mi_id
        mi_id = 1
        item1 = tree.selection()
        item = tree.get_children()
        print(item1)
        print(tree.item(item1))
        print(tree.item(item1)["values"])
        print(tree.item(item1)["text"])

        var_nombre.set(tree.item(item1)["values"][0]),
        var_apellido.set(tree.item(item1)["values"][1]),
        var_dni.set(tree.item(item1)["values"][2])
        cmbox_sexo.set(tree.item(item1)["values"][3]),
        var_telefono.set(tree.item(item1)["values"][4]),
        var_email.set(tree.item(item1)["values"][5]),
        var_direccion.set(tree.item(item1)["values"][6]),
        var_estado_de_cuenta.set(tree.item(item1)["values"][7]),

    # btn actualizar
    def update(
        self,
        var_id,
        var_nombre,
        var_apellido,
        var_dni,
        cmbox_sexo,
        var_telefono,
        var_email,
        var_direccion,
        var_estado_de_cuenta,
        tree,
    ):
        if not var_nombre:
            messagebox.showwarning("ADVERTENCIA", "No hay datos cargados")
        else:
            cadena = var_email.get()
            # patron = "([-!#-'+/-9=?A-Z^-]+(\.[-!#-'+/-9=?A-Z^-]+)|\"([]!#-[^-~ \t]|(\\[\t -]))+\")@([-!#-'+/-9=?A-Z^-]+(\.[-!#-'+/-9=?A-Z^-]+)|\[[\t -Z^-]*])"
            patron = r"\"?([-a-zA-Z0-9.`?{}]+@\w+\.\w+)\"?"
            if re.match(patron, cadena):
                item = tree.selection()
                item_id = tree.item(item)

                actualizar = Socios.update(
                    nombre=var_nombre.get(),
                    apellido=var_apellido.get(),
                    dni=var_dni.get(),
                    sexo=cmbox_sexo.get(),
                    telefono=var_telefono.get(),
                    email=var_email.get(),
                    direccion=var_direccion.get(),
                    estado_de_cuenta=var_estado_de_cuenta.get(),
                ).where(Socios.id == item_id["text"])
                actualizar.execute()
                print("la modificacion todo ok")
                messagebox.showinfo(
                    "INFORMACION",
                    "Los datos fueron modificados correctamente",
                )
                mi_id = 0
                try:
                    registrode_modificar()
                except RegistrodeError as log:
                    log.registrar_modificar()             
                self.notificar("modificar", actualizar.__dict__)
                grabado(f"modificar - {str(actualizar.__dict__)}")
            else:
                print("Invalid email")
                messagebox.showwarning(
                    "ADVERTENCIA",
                    "El email tiene caracteres inadecuados, debe corregir el email para seguir",
                )
            self.funcion_actualizartree(tree)
            var_nombre.set("")
            var_apellido.set("")
            var_dni.set("")
            cmbox_sexo.current(0)
            var_telefono.set("")
            var_email.set("")
            var_direccion.set("")
            var_estado_de_cuenta.set("")

    def funcion_actualizartree(self, tree):
        # borrar treview
        records = tree.get_children()
        for element in records:
            tree.delete(element)

        # actualizar el treeview

        for row in Socios.select():
            print(row)
            tree.insert(
                "",
                0,
                text=row.id,
                values=(
                    row.nombre,
                    row.apellido,
                    row.dni,
                    row.sexo,
                    row.telefono,
                    row.email,
                    row.direccion,
                    row.estado_de_cuenta,
                    row,
                ),
            )

    # btn borrar
    def funcion_limpiarcampos(
        self,
        var_nombre,
        var_apellido,
        var_dni,
        var_sexo,
        var_telefono,
        var_email,
        var_direccion,
        var_estado_de_cuenta,
    ):
        # limpia los entry

        var_nombre.set("")
        var_apellido.set("")
        var_dni.set("")
        var_sexo.current(0)
        var_telefono.set("")
        var_email.set("")
        var_direccion.set("")
        var_estado_de_cuenta.set("")

    def funcion_v(self):
        messagebox.showinfo(
            "INFORMATIVO",
            "La version es 1.0",
        )

    def funcion_i(self):
        messagebox.showinfo(
            "INFORMATIVO",
            "Integrantes Tamara Kivatinetz 31763556, Mariela Pacheco 40096355, Vanessa Novoa 22923538",
        )
