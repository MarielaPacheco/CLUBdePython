import datetime
import os
import socketserver

HOST = "localhost"
PORT = 9000

BASE_DIR = os.path.dirname((os.path.abspath(__file__)))
RUTA = os.path.join(BASE_DIR, "Log_suceso.txt")


class MyUDPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        dato = self.request[0].strip()
        log_suceso = open(RUTA, "a")
        print(f"Servidor - Mensaje: {dato}")
        print(
            f"Server {datetime.datetime.now()}: dato={dato.decode('UTF-8')}",
            file=log_suceso,
        )


if __name__ == "__main__":
    with socketserver.UDPServer((HOST, PORT), MyUDPHandler) as server:
        server.serve_forever()