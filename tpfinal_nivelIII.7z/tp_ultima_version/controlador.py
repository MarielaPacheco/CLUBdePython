from tkinter import Tk
from vista import Ventana
import os
from tkinter import *
import observador
from observador import ConcreteObserverA


class Controller:
    def __init__(self, master):
        self.master_controller = master
        self.objeto_vista = Ventana(self.master_controller)
        self.observador = ConcreteObserverA(self.objeto_vista.obj)


if __name__ == "__main__":
    master_tk = Tk()
    application = Controller(master_tk)

    application.objeto_vista.actualizar()
    master_tk.mainloop()




