import os

class RegistroLogError(Exception):
    """Excepción para registrar logs en un archivo"""
    BASE_DIR = os.path.dirname((os.path.abspath(__file__)))
    ruta = os.path.join(BASE_DIR, "log_abmc_socios.txt")

    def __init__(self, archivo, funcion, error, fecha):
        """Constructor de la clase RegistroLogError

        Args:
            :archivo (str): Nombre del archivo donde ocurrió la excepción
            :funcion (str): Nombre de la función donde ocurrió la excepción
            :error (str): Descripción de la excepción
            :fecha (datetime): Momento en que ocurrió la excepción
        """
        self.archivo = archivo
        self.funcion = funcion
        self.error = error
        self.fecha = fecha

    def registrar_error(self):
        """Persistir información de la excepción en el archivo de log
        
        Returns:
            Any
        """
        log = open(self.ruta, "a")
        print(f"Error: file={self.archivo}, function={self.funcion}, error={self.error}, date={self.fecha}", file=log)
