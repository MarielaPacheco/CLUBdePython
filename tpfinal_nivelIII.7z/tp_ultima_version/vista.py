from tkinter import StringVar
from tkinter import ttk
from tkinter import Button
from tkinter.ttk import Combobox
from tkinter import *
from modelo import Abmc
from cls.parametros_vista import Pantalla
from cls.estilo import b1_bg, b1_size, b_bg, b_fg, b_font, b_style
import os
import sys
from PIL import ImageTk, Image

import subprocess
from pathlib import Path
import sqlite3
import subprocess
import threading
import time
import datetime
import socket
import secrets
import pprint
import binascii

sex = [" ", "Femenino", "Masculino"]

theproc=""
class Ventana():
    def __init__(self, window) -> None:

        # ----- View -----
        # ----- Titulo de ventana -----
        window.title("Club Social Python")
        window.geometry("850x550")

        self.master = window
        self.obj = Abmc()
        self.obj1 = Pantalla(self.master)

        # ----- Imagen de fondo -----
        # BASE_DIR = os.path.dirname(__file__)
        # ruta = os.path.join(BASE_DIR, "img", "fondotp.jpg")
        # self.obj1.master.iconbitmap(os.path.join(ruta,"icono.ico"))

        # image2 = PhotoImage(file="fondotp.jg")
        # print(image2)
        # image1 = ImageTk.PhotoImage(image2)
        # print(image1)
        # self.background_label = Tk.label(image=image2, justify=CENTER)
        # self.background_label.place(x=0, y=0, relwidth=1, relheight=1)
        # self.background_label.config(bg="gray")

        # ----- Titulo -----
        self.obj1.titulos()

        # ----- tipo de datos -----
        self.var_id = int()
        self.var_nombre = StringVar()
        self.var_apellido = StringVar()
        self.var_dni = StringVar()
        self.var_sexo = StringVar()
        self.var_telefono = StringVar()
        self.var_email = StringVar()
        self.var_direccion = StringVar()
        self.var_estado_de_cuenta = StringVar()

        # ----- labels -----
        self.obj1.nombre_label("Nombre", 1, 0, "E")

        self.obj1.apellido_label("Apellido", 2, 0, "E")

        self.obj1.dni_label("DNI", 3, 0, "E")

        self.obj1.sexo_label("Sexo", 4, 0, "E")

        self.obj1.telefono_label("Telefono", 5, 0, "E")

        self.obj1.email_label("Email", 6, 0, "E")

        self.obj1.direccion_label("Direccion", 7, 0, "E")

        self.obj1.estado_de_cuenta_label("Estado de Cuenta", 8, 0, "E")

        # ----- entry -----
        self.obj1.nombre_entry(self.var_nombre, 50, 1, 1)

        self.obj1.apellido_entry(self.var_apellido, 50, 2, 1)

        self.obj1.dni_entry(self.var_dni, 50, 3, 1)

        self.cmbox_sexo = Combobox(self.master, width=46, value=sex, state="readonly")
        self.cmbox_sexo.grid(row=4, column=1)
        self.cmbox_sexo.current(0)

        self.obj1.telefono_entry(self.var_telefono, 50, 5, 1)

        self.obj1.email_entry(self.var_email, 50, 6, 1)

        self.obj1.direccion_entry(self.var_direccion, 50, 7, 1)

        self.obj1.estado_de_cuenta_entry(self.var_estado_de_cuenta, 50, 8, 1)

        # ----- treeview -----
        self.tree = ttk.Treeview(self.master)
        self.estilo = ttk.Style()
        self.estilo.configure("Treeview.Heading", font=("Arial", 8))
        self.tree["columns"] = (
            "col1",
            "col2",
            "col3",
            "col4",
            "col5",
            "col6",
            "col7",
            "col8",
        )
        self.tree.heading("#0", text="item", anchor=CENTER)
        self.tree.heading("#1", text="Nombre", anchor=CENTER)
        self.tree.heading("#2", text="Apellido", anchor=CENTER)
        self.tree.heading("#3", text="DNI", anchor=CENTER)
        self.tree.heading("#4", text="Sexo", anchor=CENTER)
        self.tree.heading("#5", text="Telefono", anchor=CENTER)
        self.tree.heading("#6", text="Email", anchor=CENTER)
        self.tree.heading("#7", text="Direccion", anchor=CENTER)
        self.tree.heading("#8", text="Estado De Cuenta", anchor=CENTER)
        self.tree.column("#0", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col1", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col2", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col3", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col4", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col5", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col6", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col7", width=80, minwidth=80, anchor=CENTER)
        self.tree.column("col8", width=100, minwidth=80, anchor=CENTER)
        self.tree.grid(padx=15, column=0, row=12, columnspan=4)

        # ----- menubar -----

        self.menubar = Menu(self.master)
        self.menu_archivo = Menu(self.menubar, tearoff=0)
        self.menu_archivo.add_command(
            label="Consultar",
            command=lambda: self.funcion_consultar(),
        )
        self.menu_archivo.add_command(
            label="Guardar",
            command=lambda: self.funcion_guardar(),
        )
        self.menu_archivo.add_command(
            label="Eliminar", command=lambda: self.funcion_eliminar()
        )
        self.menu_archivo.add_command(
            label="Actualizar",
            command=lambda: self.update(),
        )
        self.menu_archivo.add_command(
            label="Borrar",
            command=lambda: self.funcion_limpiarcampos(),
        )
        self.menu_archivo.add_separator()  # separador de menues -----
        self.menu_archivo.add_command(label="Salir", command=self.master.quit)
        self.menubar.add_cascade(label="Archivo", menu=self.menu_archivo)
        # aca esoy agregando otro menu
        self.menu_version = Menu(self.menubar, tearoff=0)
        self.menu_version.add_command(
            label="Version", command=lambda: self.obj.funcion_v()
        )
        self.menu_version.add_command(
            label="Integrantes", command=lambda: self.obj.funcion_i()
        )
        self.menubar.add_cascade(label="Datos", menu=self.menu_version)
        self.master.config(menu=self.menubar)

        self.boton_g = Button(
            self.master,
            text="Guardar",
            command=lambda: self.funcion_guardar(),
        )
        self.boton_g.config(
            font=(b_font, b1_size, b_style),
            bg=b_fg,
            fg=b_bg,
            width=15,
        )
        self.boton_g.grid(row=1, column=2, sticky=N)

        self.boton_f = Button(
            self.master,
            text="Eliminar",
            command=lambda: self.funcion_eliminar(),
        )
        self.boton_f.config(
            font=(b_font, b1_size, b_style),
            bg=b1_bg,
            fg=b_bg,
            width=15,
        )
        self.boton_f.grid(row=20, column=2, sticky=N)

        self.boton_c = Button(
            self.master,
            text="Consultar",
            command=lambda: self.funcion_consultar(),
        )
        self.boton_c.config(
            font=(b_font, b1_size, b_style),
            bg=b_fg,
            fg=b_bg,
            width=15,
        )
        self.boton_c.grid(row=5, column=2, sticky=N)

        self.boton_m = Button(
            self.master,
            text="Actualizar",
            command=lambda: self.update(),
        )
        self.boton_m.config(
            font=(b_font, b1_size, b_style),
            bg=b_fg,
            fg=b_bg,
            width=15,
        )
        self.boton_m.grid(row=7, column=2, sticky=N)

        self.boton_d = Button(
            self.master,
            text="Borrar",
            command=lambda: self.funcion_limpiarcampos(),
        )
        self.boton_d.config(
            font=(b_font, b1_size, b_style),
            bg=b_fg,
            fg=b_bg,
            width=15,
        )
        self.boton_d.grid(row=3, column=2)
        
        #AGREGO RUTA A SERVIDOR
        self.raiz = Path(__file__).resolve().parent
        self.ruta_server = os.path.join(self.raiz,'servidorestp.py')
    
        #self.titulo = Label(self.master, text="Ingrese sus datos", bg="DarkOrchid3", fg="thistle1", height=1, width=60)
        #self.titulo.grid(row=0, column=0, columnspan=4, padx=1, pady=1, sticky="w")

        self.boton_alta_serv=Button(self.master, text="Prender", command=lambda:self.try_connection())
        self.boton_alta_serv.grid(row=21, column=1)

        self.boton_borrar_serv=Button(self.master, text="Apagar", command=lambda:self.stop_server())
        self.boton_borrar_serv.grid(row=21, column=3)
        
        # ----- botones -----
    #Botones para el funcionamiento del servidor
    def prender(self,):
        print("prender")

    def try_connection(self, ): 
       
        if theproc != "":
            theproc.kill()
            threading.Thread(target=self.lanzar_servidor, args=(True,), daemon=True).start()
        else:
            print("prender")
            threading.Thread(target=self.lanzar_servidor, args=(True,), daemon=True).start()
        
    
    def lanzar_servidor(self, var):

        the_path =  self.ruta_server
        if var==True:
            global theproc
            theproc = subprocess.Popen([sys.executable, the_path])
            theproc.communicate()
        else:
            print("1")

    # =================== INNIT AND STOP SERVER ====================== 
    def stop_server(self, ):

        global theproc
        if theproc !="":
            theproc.kill() 
            print("apagar")
        
        

    def funcion_guardar(
        self,
    ):
        self.obj.funcion_guardar(
            self.var_nombre,
            self.var_apellido,
            self.var_dni,
            self.cmbox_sexo,
            self.var_telefono,
            self.var_email,
            self.var_direccion,
            self.var_estado_de_cuenta,
            self.tree,
        )

    def funcion_eliminar(
        self,
    ):
        self.obj.funcion_eliminar(self.tree)

    def funcion_consultar(
        self,
    ):
        self.obj.funcion_consultar(
            self.var_id,
            self.var_nombre,
            self.var_apellido,
            self.var_dni,
            self.cmbox_sexo,
            self.var_telefono,
            self.var_email,
            self.var_direccion,
            self.var_estado_de_cuenta,
            self.tree,
        )

    def actualizar(
        self,
    ):
        self.obj.funcion_actualizartree(self.tree)

    def funcion_limpiarcampos(
        self,
    ):
        self.obj.funcion_limpiarcampos(
            self.var_nombre,
            self.var_apellido,
            self.var_dni,
            self.cmbox_sexo,
            self.var_telefono,
            self.var_email,
            self.var_direccion,
            self.var_estado_de_cuenta,
        )

    def update(
        self,
    ):
        self.obj.update(
            self.var_id,
            self.var_nombre,
            self.var_apellido,
            self.var_dni,
            self.cmbox_sexo,
            self.var_telefono,
            self.var_email,
            self.var_direccion,
            self.var_estado_de_cuenta,
            self.tree,
        )
